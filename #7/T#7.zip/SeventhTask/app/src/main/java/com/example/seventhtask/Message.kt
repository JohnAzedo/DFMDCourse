package com.example.seventhtask

data class Message(var title: String, var text: String) {
}